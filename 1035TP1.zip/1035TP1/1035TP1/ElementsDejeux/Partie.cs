﻿using _1035TP1.Event;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1035TP1.X
{
    /// <summary>
    /// une class qui représente d'une partie de « Pêche| Pioche » 
    /// </summary>
    class Partie
    {
        /// <summary>
        /// les variable d'instances
        /// </summary>
        private JeuxDeCarte jeuxDeCarte;
        private List<Joueur> joueurs;

        public Partie(List<Joueur> joueurs)//constructeur
        {
            jeuxDeCarte = new JeuxDeCarte();
            this.joueurs = joueurs;
            pickJoueur();
        }
        /// <summary>
        /// les methodes
        /// </summary>
        private void pickJoueur()//meler les joueurs
        {
            List<Joueur> newDeck = new List<Joueur>();
            bool[] assigned = new bool[joueurs.Count];
            Random indexRandom = new Random();
            for (int i = 0; i < joueurs.Count; i++)
            {
                int joueurIndex = 0;
                bool foundJoueur = false;
                while (foundJoueur == false)
                {
                    joueurIndex = indexRandom.Next(joueurs.Count);
                    if (assigned[joueurIndex] == false)
                        foundJoueur = true;
                }
                assigned[joueurIndex] = true;
                newDeck.Add(joueurs[joueurIndex]);
            }
            joueurs = newDeck;           
        }

        public void commencer()
        {
            int count = 0;
            Console.WriteLine("la partie est ete creer!");
            Console.WriteLine("******************************");
            foreach (Joueur joueur in joueurs)
            {
                    jeuxDeCarte.join(joueur);
                    joueur.CartesEnMain = jeuxDeCarte.sendCartesEnMain();
                    Console.WriteLine(joueur.ToString() + "joint la partie");
                    count++;
            }
            Console.WriteLine("*********************");
           
            
                while (true)
                {
                foreach (Joueur joueur1 in joueurs) {
                    joueur1.play();
                   
                }
                }
            }
           
        
       
    }
}
