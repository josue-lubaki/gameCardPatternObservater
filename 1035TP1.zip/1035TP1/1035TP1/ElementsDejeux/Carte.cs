﻿
using _1035TP1.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace _1035TP1.X
{

    /// <summary>
    /// un struct qui représente une carte
    /// </summary>
    struct Carte
    {

        /// <summary>
        /////les variables d'instances
        /// </summary>
        private Valeur valeur;
        private Couleur couleur;
        //public static int n = 0;

        public Carte(Valeur valeur, Couleur couleur)//costructeur
        {
            this.valeur = valeur;
            this.couleur = couleur;
            //n++;
        }
        
        /// <summary>
        /// le methodes
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "le " + valeur + " de " + couleur;

        }
        public static bool operator ==(Carte a, Carte b)
        {
            return (a.couleur == b.couleur || a.valeur == b.valeur);
        }

        public static bool operator !=(Carte a, Carte b)
        {
            return (a.couleur != b.couleur && a.valeur != b.valeur);
        }
    }
}
