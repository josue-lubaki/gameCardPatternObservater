﻿
using _1035TP1.Enum;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using _1035TP1.Event;

namespace _1035TP1.X {

    /// <summary>
    /// la class qui représente une jeux de carte,hors cela il est un observateur de evenement depot et prioche
    /// </summary>
    class JeuxDeCarte
    {
        /// <summary>
        /// les variables d'instances
        /// </summary>
        private List<Carte> pileDePioches;
        private List<Carte> pileDeDepot;
        public JeuxDeCarte()//constructeur
         {
            pileDeDepot = new List<Carte>();
            pileDePioches = new List<Carte>();
             for (int couleurVal = 0; couleurVal < 4; couleurVal++)
             {
                 for (int valeur = 1; valeur < 14; valeur++)
                    pileDePioches.Add(new Carte((Valeur)valeur, (Couleur)couleurVal));
             }
            
            Shuffle();
         }
        /// <summary>
        /// les getter et setter pour les variables d'instance
        /// </summary>
         public List<Carte> PileDePioches
        {
             get
             {
                 return pileDePioches;
             }
         }
        public List<Carte> PileDeDepot
        {
            get
            {
                return pileDeDepot;
            }
        }
        /// <summary>
        /// les methode
        /// </summary>
        private void Shuffle()//battre les cartes
         {
            List<Carte> newDeck = new List<Carte>();
             bool[] assigned = new bool[pileDePioches.Count];
             Random sourceGen = new Random();
             for (int i = 0; i < pileDePioches.Count; i++)
             {
                 int destCard=0;
                 bool foundCard = false;
                 while (foundCard == false)
                 {
                     destCard = sourceGen.Next(pileDePioches.Count);
                     if (assigned[destCard] == false)
                         foundCard = true;
                 }
                 assigned[destCard] = true;
                newDeck.Add(pileDePioches[destCard]);                              
            }

            pileDePioches = newDeck;
         }   
        public List<Carte> sendCartesEnMain()//distrubue les cartes pour chaque joueur
        {
            List<Carte> cartesEnMain = new List<Carte>();
            Shuffle();
            for (int i = 0; i < 8; i++)
            {
                cartesEnMain.Add(pileDePioches[0]);
                pileDePioches.RemoveAt(0);

            }
            
            if (pileDePioches.Count < 8)
                Console.WriteLine("erreur!");
                
            return cartesEnMain;
        }
        private void change()//la methode pour : Quand la pile de pioches est finie, la pile de dépôt(mélangée) va être réutilisée comme pile de pioches.
        {
            List<Carte> newList = new List<Carte>();
            newList.Add(pileDeDepot[pileDeDepot.Count - 1]);
            pileDeDepot.RemoveAt(pileDeDepot.Count - 1);
            pileDePioches = PileDeDepot;
            pileDeDepot = newList;
            Shuffle();
        }
        public virtual void deposer(object sender, DeopotEtPiocheEvent e)//une methode fournir les solotion 
      //  pour afficher: a chaque tour : le joueur qui a joué, et la carte qu’il a jouée ;
        {
            if (pileDeDepot.Count == 0)//la paritie vient de conmencer ,y a pas de carte sur pile de depot
            {
                Console.WriteLine("{0} a joue la carte {1}", e.Joueur.ToString(), e.Joueur.CartesEnMain[0].ToString());
                pileDeDepot.Add(e.Joueur.CartesEnMain[0]);
                e.Joueur.CartesEnMain.RemoveAt(0);
            }
            else
            {
                int count = e.Joueur.CartesEnMain.Count;
                foreach (Carte a in e.Joueur.CartesEnMain)
                {
                    if (a == pileDeDepot[pileDeDepot.Count - 1])// les joueur va deposer la premier carte adapté
                    {
                        pileDeDepot.Add(a);
                        Console.WriteLine("{0} a joue la carte {1}", e.Joueur.ToString(), a.ToString());
                        e.Joueur.CartesEnMain.Remove(a);
                        break;
                    }
                   
                }
                if (e.Joueur.CartesEnMain.Count == 0)//quand un joueur a depose sa dernier carte ,il gargne la partie
                {
                    Console.WriteLine("{0} a gagnez!!", e.Joueur.ToString());
                    Console.Read();
                   Environment.Exit(0);
                }

                if (count == e.Joueur.CartesEnMain.Count)//quand un joueur n'a pas de carte,il va piocher une carte sur la pile de pioche
                {
                    pioche(e);
                }
            }

        }
        public void join(Joueur x)
        {
            x.Handlers += deposer;
        }
        private  void pioche(DeopotEtPiocheEvent e)//la methode de pioche
        {
            Console.WriteLine("{0} a pioche la carte {1}", e.Joueur.ToString(), pileDePioches[pileDePioches.Count - 1].ToString());
            e.Joueur.CartesEnMain.Add(pileDePioches[pileDePioches.Count - 1]);
            pileDePioches.RemoveAt(pileDePioches.Count - 1);
            if (pileDePioches.Count == 0)
                change();
        }
    }
}
