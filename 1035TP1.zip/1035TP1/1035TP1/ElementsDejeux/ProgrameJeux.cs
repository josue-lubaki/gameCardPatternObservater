﻿using _1035TP1.Event;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1035TP1.X
{
    /// <summary>
    /// une class qui implemente une partie
    /// </summary>
    class ProgrameJeux
    {
        /// <summary>
        ///  le mathode main
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            int i = 1;
            String prenom, nom;
            List<Joueur> players = new List<Joueur>();
            Console.WriteLine("Pour commencer la partie entre les information des joueurs,");
            while (i ==1)
            {
                Console.WriteLine("entrez le pronom");
                prenom = Console.ReadLine();
                Console.WriteLine("entrez le nom de la famile");
                nom = Console.ReadLine();
                players.Add(new Joueur(prenom, nom));
                Console.WriteLine("press 1 pour contiuner\npress 0 pour terminer et commencer une partie");
                int x = ReadInt();
                if (x == 0 && players.Count < 2)
                {
                    Console.WriteLine("au moins 2 joueurs!!");
                    Console.Read();
                    Environment.Exit(0);
                }
                else
                    i = x;
                if(players.Count>4)
                {
                    Console.WriteLine("Maximun 4 Joueur!!!");
                    Console.Read();
                    Environment.Exit(0);
                }
            }
            
            Partie partie = new Partie(players);
            partie.commencer();
            
        }
        /// <summary>
        /// une methode static 
        /// </summary>
        /// <returns></returns>
        public static int ReadInt()
        {
            int number = 0;

            number = Convert.ToInt32(Console.ReadLine());
                                                         
            return number;

        }
    }
}
