﻿using _1035TP1.Event;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _1035TP1.X {
    /// <summary>
    /// la class qui représente un joueur
    /// </summary>
    class Joueur
    {
        /// <summary>
        /// creer une type de delegate ;pour la gestion des evenements quand un joueur va deposer ou pirocher une carte
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void EventHandler(object sender, DeopotEtPiocheEvent e);
        /// <summary>
        /// les variables d'instances
        /// </summary>
        public event EventHandler Handlers;
        private String prenom, nom;
        private List<Carte> cartesEnMain;

        public Joueur(string prenom, string nom)//constructeur
        {
            this.prenom = prenom;
            this.nom = nom;

        }
        /// <summary>
        /// le getter et setter des carte de chaque joueur
        /// </summary>
        public List<Carte> CartesEnMain
        {
            get
            {
                return cartesEnMain;
            }
            set
            {
                cartesEnMain = value;
            }
        }
        /// <summary>
        /// les mathodes d'instances
        /// </summary>
        /// <param name="partie"></param>
        public void play()
        {
           // Handlers = jeuxDeCarte.deposer;
            Thread.Sleep(500);
            DeopotEtPiocheEvent e = new DeopotEtPiocheEvent(this);
            Handlers(this, e);
        }
        
        

        public override string ToString()
        {
            return "Joueur: " + prenom + " " + nom;
        }
    }
}
