﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1035TP1.Enum
{
    /// <summary>
    /// Enum représentant les valeurs de carte as,1,2,3,4,5,6,7,8,9,10,valet,dame,roi
    /// </summary>
    
        internal enum Valeur
        {
            As = 1,
            Deux,
            Trois,
            Quatre,
            Cinq,
            Six,
            Sept,
            Huit,
            Neuf,
            Dix,
            Valet,
            Dame,
            Roi
        }
    
}
