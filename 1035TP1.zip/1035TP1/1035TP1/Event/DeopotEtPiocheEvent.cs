﻿using _1035TP1.JeuxDeCarte;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1035TP1.Event
{/// <summary>
/// un class event 
/// </summary>
    class DeopotEtPiocheEvent : EventArgs
    {
        private Joueur joueur;//le champ


        public DeopotEtPiocheEvent(Joueur joueur)//constructeur
        {
            this.joueur = joueur;
        }
        public Joueur Joueur//getter
        {
            get { return joueur; }
        }
    }
}
