﻿using System;
using System.Collections.Generic;
using System.Text;
/*========================================================================== */
/*          @Authors : Josue Lubaki & Ismael Coulibaly & Xuyao Hu           */
/*==========================================================================*/
namespace Jeu_Uno.Classe
{   /** PILEDEPIOCHE.cs : implementer à partir du stack, donc ayant acces à toutes les methodes de la pile Stack [LIFO] */
    class PileDePioche
    {
        private Stack<Carte> pioche = new Stack<Carte>();
        private int Size = 0;

        // Constructor
        public PileDePioche(int taille) : base()
        {
            Size = taille;
        }
        public Stack<Carte> Pioche
        {
            get { return pioche; }
            set { pioche = value; }

        }

        //Pile est vide ?
        public bool IsNull()
        {
            if (Taille() == 0)
            {
                return true;
            }
            return false;
        }

        // Pile est pleine
        public bool IsFull()
        {
            if (Taille() == Size)
            {
                return true;
            }
            return false;
        }

        // Obtenir la carte du dessus
        public Carte Peek()
        {
            return pioche.Peek();
        }

        public void BrasserCarte()
        {
            List<Carte> brasserCarte = new List<Carte>();
            /* Prendre un chiffre au hasard et le faire correspondre à une carte 
            * sur toutes les cartes existantes dans la pile de jeu (Desk) sur la table de jeu */
             brasserCarte = new List<Carte>();
                int numberRandom = new Random().Next(0, Activity.pileDePioche.Taille());
                // Envoyer toutes les cartes de la table vers une liste
                List<Carte> transition = new List<Carte>();
                while (Activity.pileDePioche.Taille() > 0)
                { // Recuperer la carte du sommet puis le supprimer pour avoir accès au suivant
                    transition.Add(Activity.pileDePioche.Peek());
                    Activity.pileDePioche.Pop();
                }
                Carte carteRandom = null;
                while (transition.Count > 0)
                {
                    // selectionner une carte au hasard
                    numberRandom = new Random().Next(0, transition.Count);
                    carteRandom = transition[numberRandom];
                    brasserCarte.Add(carteRandom);
                    transition.Remove(carteRandom);
                }
                for(int a = 0; a < brasserCarte.Count; a++)
                {
                    carteRandom = brasserCarte[a];
                    // Ajouter dans la Pile de Pioche du jeu et Supprimer dans la Pile de jeu
                    Activity.pileDePioche.Push(carteRandom);
                }
            Console.WriteLine("\n\t\t--> La Pile de Pioche a été Brasser <--\n");
        }
        // Inserer une Carte
        public void Push(Carte item)
        {
            pioche.Push(item);
        }

        // Supprimer un élement de ma Pile
        public void Pop()
        {
            pioche.Pop();
        }

        // Obtenir la Taille de ma Pile
        public int Taille()
        {
            return pioche.Count;
        }

       /* public static implicit operator PileDePioche(PileDeJeu v)
        {
            throw new NotImplementedException();
        }*/
    }
}
